# Secure File Tool

A small Python command-line utility to encrypt and decrypt files in a directory using a personal password.

The tool is intentionally conservative:

- Encryption creates `.enc` copies and does **not** delete the original files.
- Decryption restores files and does **not** delete the encrypted files.
- Recursive processing is optional.
- Changing the desktop wallpaper is optional and only happens when `--set-wallpaper` is explicitly passed.

## Requirements

- Python 3.10+
- `cryptography`

Install dependencies:

```bash
pip install -r requirements.txt
```

## Usage

### Encrypt files in one directory

```bash
python secure_file_tool.py ./my-folder --mode encrypt
```

### Encrypt files recursively

```bash
python secure_file_tool.py ./my-folder --mode encrypt --recursive
```

### Decrypt files

```bash
python secure_file_tool.py ./my-folder --mode decrypt
```

### Decrypt files recursively

```bash
python secure_file_tool.py ./my-folder --mode decrypt --recursive
```

## Desktop wallpaper option

The project includes a default wallpaper at:

```text
assets/wallpaper.png
```

To set it after the selected operation:

```bash
python secure_file_tool.py ./my-folder --mode encrypt --recursive --set-wallpaper
```

To use a custom image:

```bash
python secure_file_tool.py ./my-folder --mode encrypt --set-wallpaper --wallpaper ./assets/my-image.png
```

Supported systems:

- Windows
- macOS
- Linux desktops compatible with GNOME `gsettings`

## Building a Windows `.exe`

Install PyInstaller:

```bash
pip install pyinstaller
```

Build:

```bash
pyinstaller --onefile secure_file_tool.py
```

The executable will be created in:

```text
dist/secure_file_tool.exe
```

Example usage on Windows:

```powershell
.\secure_file_tool.exe C:\Users\me\Documents\private --mode encrypt --recursive
```

## Important notes

The `.salt` file generated in the target folder is required for decryption. Keep it together with your encrypted files. If you lose the password or the `.salt` file, the encrypted files cannot be recovered.

Always test the tool on a small sample directory before using it with important data.
