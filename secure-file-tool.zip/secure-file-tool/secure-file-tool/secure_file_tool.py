#!/usr/bin/env python3
"""
Secure File Tool

A small command-line utility to encrypt/decrypt files in a directory using a
password-derived key. It can also set the desktop wallpaper from a local image
when explicitly requested.

Safety defaults:
- Encryption creates .enc copies and never deletes original files.
- Decryption creates restored copies and never deletes encrypted files.
- Wallpaper changes are opt-in via --set-wallpaper.
"""

from __future__ import annotations

import argparse
import base64
import ctypes
import os
import platform
import subprocess
from getpass import getpass
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt


DEFAULT_EXCLUDED_DIRS = {".git", "__pycache__", "venv", ".venv", "node_modules"}
DEFAULT_ASSET_WALLPAPER = Path(__file__).resolve().parent / "assets" / "wallpaper.png"


def derive_key(password: str, salt: bytes) -> bytes:
    """Derive a Fernet-compatible key from a password and salt."""
    kdf = Scrypt(
        salt=salt,
        length=32,
        n=2**14,
        r=8,
        p=1,
    )
    return base64.urlsafe_b64encode(kdf.derive(password.encode("utf-8")))


def encrypt_file(path: Path, fernet: Fernet) -> None:
    """Encrypt one file into a sibling .enc file without deleting the original."""
    if path.suffix == ".enc":
        return

    output_path = path.with_suffix(path.suffix + ".enc")
    if output_path.exists():
        print(f"[SKIP] Encrypted file already exists: {output_path}")
        return

    encrypted = fernet.encrypt(path.read_bytes())
    output_path.write_bytes(encrypted)
    print(f"[OK] Encrypted: {path} -> {output_path}")


def decrypt_file(path: Path, fernet: Fernet) -> None:
    """Decrypt one .enc file without deleting the encrypted file."""
    if path.suffix != ".enc":
        return

    output_path = path.with_suffix("")
    if output_path.exists():
        output_path = path.with_name(path.stem + ".decrypted")

    try:
        decrypted = fernet.decrypt(path.read_bytes())
    except InvalidToken:
        print(f"[ERROR] Invalid password or corrupted file: {path}")
        return

    output_path.write_bytes(decrypted)
    print(f"[OK] Decrypted: {path} -> {output_path}")


def should_skip(path: Path, root: Path, excluded_dirs: set[str]) -> bool:
    """Return True when path is inside an excluded directory."""
    try:
        relative_parts = path.relative_to(root).parts
    except ValueError:
        relative_parts = path.parts
    return any(part in excluded_dirs for part in relative_parts)


def iter_files(root: Path, recursive: bool, excluded_dirs: set[str]):
    """Yield files from root, optionally recursively."""
    candidates = root.rglob("*") if recursive else root.glob("*")
    for candidate in candidates:
        if candidate.is_file() and not should_skip(candidate, root, excluded_dirs):
            yield candidate


def process_directory(directory: str, mode: str, password: str, recursive: bool) -> None:
    """Encrypt or decrypt files in a directory."""
    root = Path(directory).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise ValueError("The provided directory does not exist or is not valid.")

    salt_path = root / ".salt"

    if mode == "encrypt":
        if not salt_path.exists():
            salt_path.write_bytes(os.urandom(16))
        salt = salt_path.read_bytes()
    else:
        if not salt_path.exists():
            raise ValueError("Missing .salt file required for decryption.")
        salt = salt_path.read_bytes()

    key = derive_key(password, salt)
    fernet = Fernet(key)

    for file_path in iter_files(root, recursive, DEFAULT_EXCLUDED_DIRS):
        if file_path.name == ".salt":
            continue
        if mode == "encrypt":
            encrypt_file(file_path, fernet)
        elif mode == "decrypt":
            decrypt_file(file_path, fernet)


def set_desktop_wallpaper(image_path: str | Path) -> None:
    """
    Set the desktop wallpaper using a local image file.

    Supported targets:
    - Windows: SystemParametersInfoW
    - macOS: osascript
    - Linux GNOME-like desktops: gsettings
    """
    image = Path(image_path).expanduser().resolve()
    if not image.exists() or not image.is_file():
        raise ValueError(f"Wallpaper image not found: {image}")

    system = platform.system().lower()

    if system == "windows":
        # 20 = SPI_SETDESKWALLPAPER, 3 = update user profile + broadcast change
        result = ctypes.windll.user32.SystemParametersInfoW(20, 0, str(image), 3)
        if not result:
            raise RuntimeError("Windows could not update the desktop wallpaper.")

    elif system == "darwin":
        script = f'tell application "System Events" to set picture of every desktop to "{image}"'
        subprocess.run(["osascript", "-e", script], check=True)

    elif system == "linux":
        uri = image.as_uri()
        subprocess.run(
            ["gsettings", "set", "org.gnome.desktop.background", "picture-uri", uri],
            check=True,
        )
        subprocess.run(
            ["gsettings", "set", "org.gnome.desktop.background", "picture-uri-dark", uri],
            check=False,
        )

    else:
        raise RuntimeError(f"Unsupported operating system: {platform.system()}")

    print(f"[OK] Desktop wallpaper set to: {image}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Encrypt/decrypt files in a directory using a personal password."
    )
    parser.add_argument("directory", help="Target directory")
    parser.add_argument("--mode", choices=["encrypt", "decrypt"], required=True)
    parser.add_argument(
        "--recursive",
        action="store_true",
        help="Process files inside subdirectories",
    )
    parser.add_argument(
        "--set-wallpaper",
        action="store_true",
        help="Set the desktop wallpaper after the selected operation",
    )
    parser.add_argument(
        "--wallpaper",
        default=str(DEFAULT_ASSET_WALLPAPER),
        help="Path to the wallpaper image. Defaults to assets/wallpaper.png",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    password = getpass("Password: ")
    process_directory(args.directory, args.mode, password, args.recursive)

    if args.set_wallpaper:
        set_desktop_wallpaper(args.wallpaper)


if __name__ == "__main__":
    main()
